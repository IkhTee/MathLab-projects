# a =int(input())

# if 90 <= a <= 100:
#     print('A1')
# elif 85 <= a <= 89:
#     print('A2')
# elif 80 <= a <= 84:
#     print('B1')
# elif 75 <= a <=79:
#     print('B2')
# elif 70<= a <= 74:
#     print('B3')
# elif 65 <= a <= 69:
#     print('C1')
# elif 60 <= a <=69:
#     print('C2')
# elif 55 <= a <= 59:
#     print("C3")
# elif 50 <= a <= 54:
#     print('D1')
# elif 45 <= a <= 49:
#     print('D2')
# elif 40 <= a <= 44:
#     print('D3')
# elif 0 <= a <= 39:
#     print('FAIL')


#PROGRAM FirstFiveEven:

# a = 3
# b = 5
# i = 0

# while i < b:
#     print(a+i)
#     i = i+1 
    
# a= 20
# b=40
# i=0
# while i<b:
#     print (a+i)
#     i = i+1



a = int (input("Enter a number"))
total = 1 
for i in range (1, a + 1):
    print(i)
    total *=1
    print(total)







