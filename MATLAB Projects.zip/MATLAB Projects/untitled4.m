f = @(x) (1-x.^2).^(5/2);                   
fd = @(x) (5/2)*(1-x.^2).^(5/2-1).*(-2*x);  
f0 = fd(-1);
fn = fd(1);
xplot = linspace(-1,1);
f_xplot = f(xplot);
for k = 2:5
    n = 2^k;
    x = -1+2*(0:n)/n;
    y = f(x);
    s = spline(x,y,xplot);           
    s1 = spline(x,[f0 y fn],xplot);   
    figure(1)
    plot(x,y,'ko',xplot,f_xplot,'r',xplot,s,'b',xplot,s1,'g','linewidth',3)
    legend('dati','f(x)','sspline not-a-knot','spline 1st der costr')
    pause
    figure(2)
    semilogy(xplot,abs(s-f_xplot),'b',xplot,abs(s1-f_xplot),'g','linewidth',3)
    legend('spline not-a-knot error','spline 1st der costr - error')
    err = norm(f_xplot-s,inf)
    err1 = norm(f_xplot-s1,inf)
    pause
end    

