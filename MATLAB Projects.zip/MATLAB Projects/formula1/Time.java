package formula1;


public class Time {

	@Override
	public String toString(){
		return null;
	}
}
