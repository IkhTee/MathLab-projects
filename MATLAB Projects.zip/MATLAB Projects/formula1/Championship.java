package formula1;

import java.util.Collection;
import java.util.List;

public class Championship {

	/**
	 * Creates a new driver and puts it in the championship
	 * @param name -> driver's name (e.g. "Vettel")
	 */
	
	public Driver createDriver(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return the list of Drivers
	 */
	
	public Collection<Driver> getDrivers() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param driver's name
	 * @return the corresponding Driver object
	 */
	
	public Driver getDriver(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param GP name (Es. "Monza")
	 * @return the corresponding GP object 
	 */
	
	public GP defineGrandPrix(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param GP name
	 * @return the corresponding GP object
	 */
	
	public GP getGrandPrix(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param gp
	 * @param r
	 * @param hours
	 * @param min
	 * @param sec
	 * @param cent
	 * @return Time object
	 */
	
	public Time setTime(GP gp, Driver r, int hours, int min, int sec, int cent) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return drivers ranking sorted according to their points
	 */
	
	public List<Driver> getChampionshipRanking() {
		// TODO Auto-generated method stub
		return null;
	}

}
