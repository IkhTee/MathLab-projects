package formula1;

import java.util.List;

public class GP {

	/**
	 * @return GP name
	 */

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return list of Driver Objects sorted in ascending way according to the race time 
	 */

	public List<Driver> getGPRanking() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param Driver Object
	 * @return ranking (starting from 1)
	 */

	public int getPosition(Driver driver)  {
		// TODO Auto-generated method stub
		return 0;
	}

}
