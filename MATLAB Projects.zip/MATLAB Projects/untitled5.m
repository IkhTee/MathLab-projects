format long
i = 1;
ord = 5:5:15;
for n = ord
    A = hilb(n);
    Kinf(i)=cond(A,inf);
    b = sum(A,2);
    x = A\b;
    err(i) = norm(ones(n,1)-x,inf)/norm(ones(n,1),inf);
    i=i+1;
end
[ord' Kinf']

