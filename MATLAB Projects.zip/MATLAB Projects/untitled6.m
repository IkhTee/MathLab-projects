n = 100;
for i = 1:n
    for j = 1:n
        A(i,j) = max([i j]);
    end
end
Kinf = cond(A,inf)
b = sum(A,2);
[L,U] = elleu(A);
y = L\b;        
x_nopiv = U\y;
err_nopiv = norm(ones(n,1)-x_nopiv)/norm(ones(n,1))

[L,U,P] = lu(A);  
y = L\(P*b);
x_piv = U\y;
err_piv = norm(ones(n,1)-x_piv)/norm(ones(n,1))
