a = -5;
b = 5;
f = @(x) 1./(1+x.^2);
xplot = linspace(a,b);
f_xplot = f(xplot);
figure
for n = 5:4:13
    x = linspace(a,b,n+1);
    y = f(x);
    s = spline(x,y,xplot)
    plot(x,y,'ko',xplot, f_xplot,'r',xplot,s,'b','linewidth',3)
    err = norm(s-f_xplot,inf)
    pause
end

