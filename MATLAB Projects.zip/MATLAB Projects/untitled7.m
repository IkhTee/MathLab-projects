n = 100;
for i = 1:n
    for j = 1:n
        A(i,j) = i*max([i j]);
    end
end
determinante = det(A)
[L,U,P] = lu(A);
inverse_c = inv(U)*inv(L)*P;
inverse = inv(A);
err = norm(inverse-inverse_c,inf)
