    public interface VehicleFactory {
        Vehicle createVehicle();
    }