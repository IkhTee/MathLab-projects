public class ThreeWheeler extends Vehicle {
    @Override
    public void printVehicle() {
        System.out.println("I am a three-wheeler");
    }
}
