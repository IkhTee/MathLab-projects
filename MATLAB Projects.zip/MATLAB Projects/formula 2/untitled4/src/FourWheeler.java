public class FourWheeler extends Vehicle {
    @Override
    public void printVehicle() {
        System.out.println("I am a four-wheeler");
    }
}