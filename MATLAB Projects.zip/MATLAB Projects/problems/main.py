# nums=[2,-3,1,2,3,1,4,-6,7,-5,-1]

# for i in range(len(nums)):
#    sums=0
#    for j in range(i,len(nums)):
#         sums+=nums[j]
#         if sums==0:
#             print(f"Sub-array starting from index {i}, length {j-i+1} ")
        


# nums = [1,2,3,4,5]

# print(nums.__iadd__)


# nums = nums +[2,3,4,5]
# print(nums.__iadd__)

a = 12
print(hex(id(a)))