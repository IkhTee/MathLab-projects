  p = 30;
n = 100;
A = rand(n);
b = sum(A,2);
x = zeros(n,p); %x is a matrix nxp. The solution of i-system is stored in the i-column
tic         %start to compute time
[L,U,P] = lu(A);
tn = P*b;
for i = 1:p
    %v = L\tn;
    x(:,i) = L\(U\tn);
    tn = P*x(:,i);
end
toc     %stop to compute time. It prints elapsed time

tic
x(:,1) = A\b;
for i = 2:p
    x(:,i) = A\x(:,i-1);
end
toc
