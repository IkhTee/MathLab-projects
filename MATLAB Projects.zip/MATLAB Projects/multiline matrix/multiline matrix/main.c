#include <stdio.h>
#include <stdlib.h>
#define size 3

int main()
{//getting elements of matrix


    int i, j, matrix[size][size], r;
    for(i=0; i<size; i++)
    {
        for(j=0; j<size; j++)
        {
            printf("Enter %d,%d value: ", i+1, j+1);
            scanf("%d", &matrix[i][j]);

        }
    }
    printf("Enter value for r: "); scanf("%d", &r);
    printf("\n");


//when r is more then 0
    if(r>0){
        for(j=0; j<size; j++){
            for(i=size-1; i>=0; i--){
                printf("%3d", matrix[i][j]);
            }
        printf("\n");
        }
    }


//when r is less then 0
    if(r<0){
        for(j=size-1; j>=0; j--){
            for(i=0; i<size; i++){
                printf("%3d", matrix[i][j]);
            }
        printf("\n");
        }
    }


//when r is equal to 0
    if(r==0){
        for(i=size-1; i>=0; i--){
            for(j=size-1; j>=0; j--){
                printf("%3d", matrix[i][j]);
          }
        printf("\n");
        }
    }
    return 0;
}
